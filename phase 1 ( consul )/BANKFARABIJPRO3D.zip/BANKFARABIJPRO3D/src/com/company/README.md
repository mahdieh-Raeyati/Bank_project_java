## BANK FARABI

**description** : this project is based on a virtual bank named Farabi. there are 4 levels of accessibility : admin , manager , employee & customer. each of them has specific abilities. 
there's only one admin who has the entire system's administration. manager is created by admin & he/she is the person who conducts the bank and has access to all features & settings : eg. adding or editing employees...
customers can be created by themselves( using sign up option at the beginning of the program ) or by employees and manager. 
as anyone become a member of the bank, a menu is shown and they can choose their proper
item among available options.




+ a project by : Arefeh Ataei - Mahdieh Raeyati - Fatemeh Pakmehr

+ (Written in java **;**)


+ phases :

1- consul  
2- graphic  
3- multi threading

- used jar libraries :

1- Gson  


`( this project is provided in 2 versions : consul & graphical)`